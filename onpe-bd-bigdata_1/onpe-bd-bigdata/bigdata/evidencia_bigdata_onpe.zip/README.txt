EVIDENCIA DE IMPLEMENTACIÓN — Script PySpark (sección 5.11 del informe)
=========================================================================

Esto es el mismo código que está en el informe (sección 5.11.3), ya
PROBADO Y EJECUTADO de verdad, con un dataset de prueba representativo
(mismos campos que BD_ONPE: ubigeo, proceso_electoral, id_proceso,
porcentaje_participacion) para poder mostrar evidencia real, no solo
una tabla escrita a mano.

ARCHIVOS:
  generar_datos.py                 -> genera el dataset de prueba (72 filas,
                                       12 distritos x 6 procesos electorales,
                                       con una "semilla" fija para que el
                                       resultado sea siempre reproducible)
  convertir_a_parquet.py           -> convierte el CSV generado a formato
                                       Parquet (el mismo formato que usa el
                                       script del informe)
  onpe_participacion_historica.py  -> EL SCRIPT DEL INFORME, sin cambios en
                                       la lógica (solo se ajustó la ruta de
                                       lectura para que apunte a la carpeta
                                       local en vez de /datalake/... que en
                                       el informe es la ruta "real" del
                                       Data Lake de producción)
  datalake/                        -> carpeta con el dataset de prueba
  salida_resultado/                -> resultado real de ejecutar el script
                                       (36 filas: 12 distritos x 3 tipos de
                                       proceso electoral agrupados)

CÓMO EJECUTARLO USTEDES MISMOS
-------------------------------

OPCIÓN A — Google Colab (la más fácil, no instala nada en su PC):
  1. Entrar a https://colab.research.google.com y crear un notebook nuevo.
  2. En la primera celda: !pip install pyspark
  3. Subir los 3 archivos .py y la carpeta datalake/ al notebook (ícono de
     carpeta a la izquierda > subir).
  4. En una celda nueva: !python generar_datos.py (si quieren generar el
     dataset de nuevo) y luego !python convertir_a_parquet.py
  5. Por último: !python onpe_participacion_historica.py
  Colab ya trae Java instalado, así que PySpark funciona sin configurar
  nada más.

OPCIÓN B — En su propia PC:
  Requisitos: Python 3.9+ y Java 17 o 21 instalados.
  1. python -m venv venv
  2. venv\Scripts\activate          (Windows)   o   source venv/bin/activate (Mac/Linux)
  3. pip install pyspark
  4. python generar_datos.py
  5. python convertir_a_parquet.py
  6. python onpe_participacion_historica.py

En ambos casos, la salida que deberían ver en pantalla es la misma tabla
que aparece en el informe (PIURA y LIMA con la participación promedio más
alta, etc.) — así cualquiera del equipo puede mostrar esto corriendo en
vivo si el profesor pregunta, no solo como texto en el Word.
